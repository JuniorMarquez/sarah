<?php

$_['text_comment']  		= 'Comment by';
?>