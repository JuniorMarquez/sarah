<?php
// Heading
$_['heading_title']    = 'Boss - Theme Manager';
