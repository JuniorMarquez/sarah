
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `oc_btslider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_btslider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `oc_btslider` DISABLE KEYS */;
INSERT INTO `oc_btslider` VALUES (1,'{\"slider_type\":\"custom\",\"slider_width\":\"570\",\"slider_height\":\"444\",\"delay\":\"5000\",\"startWithSlide\":\"0\",\"stopslider\":\"off\",\"stopafterloops\":\"-1\",\"stopatslide\":\"-1\",\"touchenabled\":\"on\",\"onhoverstop\":\"off\",\"timeline\":\"on\",\"shadow\":\"0\",\"navigationtype\":\"bullet\",\"navigationarrow\":\"solo\",\"navigationstyle\":\"square\",\"navigationhalign\":\"center\",\"navigationvalign\":\"bottom\",\"navigationhoffset\":\"0\",\"navigationvoffset\":\"15\",\"soloarrowlefthalign\":\"left\",\"soloarrowleftvalign\":\"center\",\"soloarrowlefthoffset\":\"0\",\"soloarrowleftvoffset\":\"0\",\"soloarrowrighthalign\":\"right\",\"soloarrowrightvalign\":\"center\",\"soloarrowrighthoffset\":\"0\",\"soloarrowrightvoffset\":\"0\",\"timehidethumbnail\":\"0\",\"thumbnailwidth\":\"0\",\"thumbnailheight\":\"0\",\"thumbamount\":\"0\",\"hidecapptionatlimit\":\"0\",\"hideallcapptionatlimit\":\"0\",\"hideslideratlimit\":\"0\"}');
/*!40000 ALTER TABLE `oc_btslider` ENABLE KEYS */;
DROP TABLE IF EXISTS `oc_btslider_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_btslider_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slider_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `slideset` text,
  `caption` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `oc_btslider_slide` DISABLE KEYS */;
INSERT INTO `oc_btslider_slide` VALUES (1,1,1,0,'{\"url\":\"#\",\"enablelink\":\"1\",\"type_background\":\"image_bg\",\"background\":\"catalog/bt_slide/slide-1.png\",\"transitions\":\"random\",\"slotamount\":\"7\",\"masterspeed\":\"500\",\"delay\":\"5000\",\"target\":\"_self\",\"kenburns\":\"off\",\"enablefullvideo\":\"1\"}','[{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-image-1.png\",\"datax\":\"40\",\"type_caption\":\"image\",\"datay\":\"75\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"100\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sfl\",\"outgo_animation\":\"stl\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"},{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-text-1.png\",\"datax\":\"275\",\"type_caption\":\"image\",\"datay\":\"125\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"100\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"},{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-text-2.png\",\"datax\":\"275\",\"type_caption\":\"image\",\"datay\":\"160\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"200\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"},{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-text-3.png\",\"datax\":\"275\",\"type_caption\":\"image\",\"datay\":\"225\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"300\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"}]'),(2,1,1,0,'{\"url\":\"#\",\"enablelink\":\"1\",\"type_background\":\"image_bg\",\"background\":\"catalog/bt_slide/slide-1.png\",\"transitions\":\"random\",\"slotamount\":\"7\",\"masterspeed\":\"500\",\"delay\":\"5000\",\"target\":\"_self\",\"kenburns\":\"off\",\"enablefullvideo\":\"1\"}','[{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-image-1.png\",\"datax\":\"40\",\"type_caption\":\"image\",\"datay\":\"75\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"100\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"},{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-text-1.png\",\"datax\":\"275\",\"type_caption\":\"image\",\"datay\":\"125\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"100\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"},{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-text-2.png\",\"datax\":\"275\",\"type_caption\":\"image\",\"datay\":\"160\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"100\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"},{\"image_caption\":\"catalog\\/bt_slide\\/revo-1-text-3.png\",\"datax\":\"275\",\"type_caption\":\"image\",\"datay\":\"225\",\"class_css\":\"small_text\",\"dataspeed\":\"500\",\"datastart\":\"100\",\"dataend\":\"5000\",\"dataafterspeed\":\"1000\",\"incom_animation\":\"sft\",\"outgo_animation\":\"stt\",\"easing\":\"easeOutBack\",\"endeasing\":\"easeOutBack\"}]');
/*!40000 ALTER TABLE `oc_btslider_slide` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

