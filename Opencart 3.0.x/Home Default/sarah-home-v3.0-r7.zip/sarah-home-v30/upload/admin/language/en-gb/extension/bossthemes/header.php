<?php
// Heading Title
$_['heading_title'] = 'Header - Boss - Theme Manager';

// Text
$_['text_success'] = 'Success: You have just modified Header option!';

// Entry
$_['entry_mega_menu']          = 'Mega Menu';
$_['entry_link_logo']          = 'Logo';
$_['entry_link_language']      = 'Language';
$_['entry_link_currency']      = 'Currency';
$_['entry_link_mini_cart']     = 'Mini Cart';
$_['entry_link_search']        = 'Search Box';
$_['entry_link_phone']         = 'Phone';
$_['entry_link_account']       = 'Account';
$_['entry_link_wishlist']      = 'Wishlist';
$_['entry_link_shopping_cart'] = 'Shoping Cart';
$_['entry_link_checkout']      = 'Checkout';
$_['entry_name']               = 'Name';
$_['entry_icon']               = 'Icon';
$_['entry_link']               = 'Link';
$_['entry_sort_order']         = 'Sort Order';

// Tab
$_['tab_link'] = 'Custom Links';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify Header!';
$_['error_custom_link'] = 'Name must be between 1 and 128 characters!';