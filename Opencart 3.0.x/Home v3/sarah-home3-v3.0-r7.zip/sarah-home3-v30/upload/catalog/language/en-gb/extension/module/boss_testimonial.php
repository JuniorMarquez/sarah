<?php
// Heading 
$_['heading_title']	= 'Testimonials';
$_['isi_testimonial']	= 'Write testimonial';
$_['text_more']		= ' more...';
$_['text_more2']		= 'More...';
$_['show_all']		= 'Show all';
$_['text_subject']	= 'Customer %s send testimonial about %s store';
$_['text_header']		= 'Testimonial: ';
$_['text_footer']		= '';


?>