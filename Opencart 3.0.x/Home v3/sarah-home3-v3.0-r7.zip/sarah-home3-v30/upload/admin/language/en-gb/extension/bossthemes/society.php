<?php
// Heading Title
$_['heading_title'] = 'Society - Boss - Theme Manager';

// Text
$_['text_success'] = 'Success: You have just modified Society!';

// Entry
$_['entry_name']       = 'Name';
$_['entry_image']      = 'Image';
$_['entry_icon']       = 'Icon';
$_['entry_link']       = 'Link';
$_['entry_sort_order'] = 'Sort Order';

// Tab

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify Society!';
$_['error_boss_society'] = 'Society Name must be between 1 and 128 characters!';