<?php
$_['text_postby']  		= 'Post by';
?>