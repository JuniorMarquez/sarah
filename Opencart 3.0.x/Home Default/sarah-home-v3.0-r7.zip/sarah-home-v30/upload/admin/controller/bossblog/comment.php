<?php
class ControllerBossblogComment extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('bossblog/comment');
		$_languages = $this->language->all();
		$data = (isset($data)) ? array_merge($data, $_languages) : $_languages;

        $this->load->model('bossblog/comment');

		$this->document->setTitle($this->language->get('heading_title'));

        //$this->document->addStyle('view/stylesheet/bossthemes/bossblog.css');

        $this->getList();
	} 

	public function insert() {
		$this->load->language('bossblog/comment');
		$_languages = $this->language->all();
		$data = (isset($data)) ? array_merge($data, $_languages) : $_languages;

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('bossblog/comment');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_bossblog_comment->addComment($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function update() {
		$this->load->language('bossblog/comment');
		$_languages = $this->language->all();
		$data = (isset($data)) ? array_merge($data, $_languages) : $_languages;

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('bossblog/comment');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_bossblog_comment->editComment($this->request->get['blog_comment_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() { 
		$this->load->language('bossblog/comment');
		$_languages = $this->language->all();
		$data = (isset($data)) ? array_merge($data, $_languages) : $_languages;

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('bossblog/comment');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $blog_comment_id) {
				$this->model_bossblog_comment->deleteComment($blog_comment_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		$this->response->redirect($this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
		$this->getList();
	}

	private function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'bc.date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL'),
      		'separator' => false
   		);

        $data['breadcrumbs'][] = array(
			'href'      => $this->url->link('extension/module/bossblog', 'user_token=' . $this->session->data['user_token'], 'SSL'),
			'text'      => $this->language->get('heading_bossblog'),
			'separator' => ' :: '
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'], 'SSL'),
      		'separator' => ' :: '
   		);

		/*  New Boss Blog */
         $data['boss_category'] = $this->url->link('bossblog/category', 'user_token=' . $this->session->data['user_token'], 'SSL');
         $data['boss_articles'] = $this->url->link('bossblog/articles', 'user_token=' . $this->session->data['user_token'], 'SSL');
         $data['boss_comments'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'], 'SSL');
         $data['boss_settings'] = $this->url->link('bossblog/setting', 'user_token=' . $this->session->data['user_token'], 'SSL');
        /* End New Boss Blog */
		$data['insert'] = $this->url->link('bossblog/comment/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
		$data['delete'] = $this->url->link('bossblog/comment/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');	
		$data['repair'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token']. $url, 'SSL');
		$data['comments'] = array();

		$data_sort = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

        $this->load->model('bossblog/comment');

		$comment_total = $this->model_bossblog_comment->getTotalComments();

		$results = $this->model_bossblog_comment->getComments($data_sort);

    	foreach ($results as $result) {
			$action = array();

			$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('bossblog/comment/update', 'user_token=' . $this->session->data['user_token'] . '&blog_comment_id=' . $result['blog_comment_id'] . $url, 'SSL')
			);

			$data['comments'][] = array(
				'blog_comment_id'  => $result['blog_comment_id'],
				'name'       => $result['name'],
				'author'     => $result['author'],
                'text' => utf8_substr(strip_tags(html_entity_decode($result['text'], ENT_QUOTES, 'UTF-8')), 0, 50) . '..',
				'email'     => $result['email'],
				'status'     => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'selected'   => isset($this->request->post['selected']) && in_array($result['review_id'], $this->request->post['selected']),
				'action'     => $action,
				'edit'        => $this->url->link('bossblog/comment/update', 'user_token=' . $this->session->data['user_token'] . '&blog_comment_id=' . $result['blog_comment_id'] , 'SSL'),
			);
		}	

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_article'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . '&sort=bad.name' . $url, 'SSL');
		$data['sort_author'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . '&sort=bc.author' . $url, 'SSL');
		$data['sort_email'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . '&sort=bc.email' . $url, 'SSL');
		$data['sort_status'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . '&sort=bc.status' . $url, 'SSL');
		$data['sort_date_added'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . '&sort=bc.date_added' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $comment_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');		
		$pagination->url = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

		$data['pagination'] = $pagination->render();

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('bossblog/comment_list', $data));
	}

	private function getForm() {

       //$this->document->addStyle('view/stylesheet/bossthemes/bossblog.css');

       /*  New Boss Blog */

         $data['boss_category'] = $this->url->link('bossblog/category', 'user_token=' . $this->session->data['user_token'], 'SSL');
         $data['boss_articles'] = $this->url->link('bossblog/articles', 'user_token=' . $this->session->data['user_token'], 'SSL');
         $data['boss_comments'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'], 'SSL');
         $data['boss_settings'] = $this->url->link('bossblog/setting', 'user_token=' . $this->session->data['user_token'], 'SSL');
        /* End New Boss Blog */

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['article'])) {
			$data['error_article'] = $this->error['article'];
		} else {
			$data['error_article'] = '';
		}

 		if (isset($this->error['author'])) {
			$data['error_author'] = $this->error['author'];
		} else {
			$data['error_author'] = '';
		}

 		if (isset($this->error['text'])) {
			$data['error_text'] = $this->error['text'];
		} else {
			$data['error_text'] = '';
		}

 		if (isset($this->error['email'])) {
			$data['error_email'] = $this->error['email'];
		} else {
			$data['error_email'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

   		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL'),
      		'separator' => false
   		);

        $data['breadcrumbs'][] = array(
			'href'      => $this->url->link('extension/module/bossblog', 'user_token=' . $this->session->data['user_token'], 'SSL'),
			'text'      => $this->language->get('heading_bossblog'),
			'separator' => ' :: '
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'),
      		'separator' => ' :: '
   		);

		if (!isset($this->request->get['blog_comment_id'])) { 
			$data['action'] = $this->url->link('bossblog/comment/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
		} else {
			$data['action'] = $this->url->link('bossblog/comment/update', 'user_token=' . $this->session->data['user_token'] . '&blog_comment_id=' . $this->request->get['blog_comment_id'] . $url, 'SSL');
		}

		$data['cancel'] = $this->url->link('bossblog/comment', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

		if (isset($this->request->get['blog_comment_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$comment_info = $this->model_bossblog_comment->getComment($this->request->get['blog_comment_id']);
		}

		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('bossblog/articles');

		if (isset($this->request->post['blog_article_id'])) {
			$data['blog_article_id'] = $this->request->post['blog_article_id'];
		} elseif (!empty($comment_info)) {
			$data['blog_article_id'] = $comment_info['blog_article_id'];
		} else {
			$data['blog_article_id'] = '';
		}

		if (isset($this->request->post['article'])) {
			$data['article'] = $this->request->post['article'];
		} elseif (!empty($comment_info)) {
			$data['article'] = $comment_info['article'];
		} else {
			$data['article'] = '';
		}

		if (isset($this->request->post['author'])) {
			$data['author'] = $this->request->post['author'];
		} elseif (!empty($comment_info)) {
			$data['author'] = $comment_info['author'];
		} else {
			$data['author'] = '';
		}

		if (isset($this->request->post['text'])) {
			$data['text'] = $this->request->post['text'];
		} elseif (!empty($comment_info)) {
			$data['text'] = $comment_info['text'];
		} else {
			$data['text'] = '';
		}

		if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} elseif (!empty($comment_info)) {
			$data['email'] = $comment_info['email'];
		} else {
			$data['email'] = '';
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($comment_info)) {
			$data['status'] = $comment_info['status'];
		} else {
			$data['status'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('bossblog/comment_form', $data));
	}

	private function validateForm() {
		if (!$this->user->hasPermission('modify', 'bossblog/comment')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['blog_article_id']) {
			$this->error['article'] = $this->language->get('error_article');
		}

		if ((utf8_strlen($this->request->post['author']) < 3) || (utf8_strlen($this->request->post['author']) > 64)) {
			$this->error['author'] = $this->language->get('error_author');
		}

		if (utf8_strlen($this->request->post['text']) < 1) {
			$this->error['text'] = $this->language->get('error_text');
		}

		if ((utf8_strlen($this->request->post['email']) > 96) || !preg_match('/^[^\@]+@.*\.[a-z]{2,6}$/i', $this->request->post['email'])) {
      		$this->error['email'] = $this->language->get('error_email');
    	}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	private function validateDelete() {
		if (!$this->user->hasPermission('modify', 'bossblog/comment')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}	
}
?>