<?php
// Heading
$_['heading_title']    = 'Boss - Refine Search';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Boss - Refine Search module!';
$_['text_edit']        = 'Edit Boss Refine Search Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Boss Refine Search module!';
$_['error_width']         = 'Image Width required!';
$_['error_height']         = 'Image Height required!';