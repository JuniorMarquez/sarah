<?php
// Heading Title
$_['heading_title']				= 'Sample Data - Boss - Theme Manager';

// Text
$_['text_success']				= 'Success: You have just import sample data to this module.';
$_['text_import_last']			= 'Warning: Import this module in the last, when you import completely another modules.';
$_['text_confirm']				= 'Are you sure? All the data of this module will be lost! The new data will same as homepage default.';

// Entry

// Column
$_['column_module']				= 'Module';
$_['column_action']				= 'Action';

// Tab

// Error
$_['error_permission']			= 'Warning: You do not have permission to modify Sample Data!';
$_['error_package']				= 'Error: Package is not found.';