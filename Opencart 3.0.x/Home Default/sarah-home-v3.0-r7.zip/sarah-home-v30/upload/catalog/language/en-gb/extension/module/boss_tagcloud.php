<?php
// Messages
$_['text_notags']  		= 'No tags available';
?>