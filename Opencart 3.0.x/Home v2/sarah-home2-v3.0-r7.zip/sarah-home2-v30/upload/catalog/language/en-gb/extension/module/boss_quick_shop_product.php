<?php
// Heading 

// Text
$_['text_hover_remove'] = 'Close';
$_['text_add_to_wish_list'] = 'Add To Wish List';
$_['text_add_to_compare'] = 'Add To Compare';

// Entry
$_['entry_qty'] = 'Qty';

// Button
$_['button_viewdetail'] = 'View Product Detail';