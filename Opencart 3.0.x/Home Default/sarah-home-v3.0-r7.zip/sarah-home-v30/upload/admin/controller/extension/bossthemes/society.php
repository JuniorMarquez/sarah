<?php

class ControllerExtensionBossthemesSociety extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/bossthemes/society');
		$this->load->model('setting/setting');

		$data = (isset($data)) ? array_merge($data, $this->language->all()) : $this->language->all();

		$this->document->setTitle($this->language->get('heading_title'));

		$this->document->addScript('view/javascript/bossthemes/fontawesome-iconpicker/fontawesome-iconpicker.min.js');
		$this->document->addStyle('view/javascript/bossthemes/fontawesome-iconpicker/fontawesome-iconpicker.min.css');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (isset($this->request->post['boss_society'])) {
				$sort_order = array();

				foreach ($this->request->post['boss_society'] as $key => $value) {
					$sort_order[$key] = $value['sort_order'];
				}

				array_multisort($sort_order, SORT_ASC, $this->request->post['boss_society']);
			}

			$this->model_setting_setting->editSetting('boss_society', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/bossthemes/society', 'user_token=' . $this->session->data['user_token'], 'SSL'));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['boss_society'])) {
			$data['error_boss_society'] = $this->error['boss_society'];
		} else {
			$data['error_boss_society'] = array();
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=bossthemes', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/bossthemes/society', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/bossthemes/society', 'user_token=' . $this->session->data['user_token'], 'SSL');
		if (isset($this->request->post['boss_society'])) {
			$boss_societys = $this->request->post['boss_society'];
		} elseif ($this->config->get('boss_society')) {
			$boss_societys = $this->config->get('boss_society');
		} else {
			$boss_societys = array();
		}

		$data['boss_societys'] = array();

		$this->load->model('tool/image');

		foreach ($boss_societys as $boss_society) {
			if (is_file(DIR_IMAGE . $boss_society['image'])) {
				$image = $boss_society['image'];
				$thumb = $boss_society['image'];
			} else {
				$image = '';
				$thumb = 'no_image.png';
			}

			$data['boss_societys'][] = array(
				'name' => $boss_society['name'],
				'image' => $image,
				'thumb' => $this->model_tool_image->resize($thumb, 100, 100),
				'icon' => $boss_society['icon'],
				'link' => $boss_society['link'],
				'sort_order' => $boss_society['sort_order']
			);
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$sort_order = array();

		foreach ($data['boss_societys'] as $key => $value) {
			$sort_order[$key] = $value['sort_order'];
		}

		array_multisort($sort_order, SORT_ASC, $data['boss_societys']);

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();

		$this->config->set('template_engine', 'template');
		$data['topbar']  = $this->load->controller('extension/bossthemes/topbar');
		$data['sidebar'] = $this->load->controller('extension/bossthemes/sidebar');

		$this->config->set('template_engine', 'twig');
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		$this->config->set('template_engine', 'template');

		$this->response->setOutput($this->load->view('extension/bossthemes/society', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/bossthemes/society')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (isset($this->request->post['boss_society'])) {
			foreach ($this->request->post['boss_society'] as $boss_society_id => $boss_society) {
				foreach ($boss_society['name'] as $language_id => $name) {
					if ((utf8_strlen($name) < 1) || (utf8_strlen($name) > 128)) {
						$this->error['boss_society'][$boss_society_id][$language_id] = $this->language->get('error_boss_society');
					}
				}
			}
		}

		return !$this->error;
	}
}
