<?php
class ControllerExtensionModuleBossManufacturer extends Controller {
    public function index($setting) {
        if(empty($setting)) return;
        static $module = 0;
		
		if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_category.css')) {
			$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_category.css');
		} else {
			$this->document->addStyle('catalog/view/theme/default/stylesheet/bossthemes/boss_category.css');
		}
		
		$language_id = (int)$this->config->get('config_language_id');

        $data['heading_title'] = isset($setting['title'][$language_id]) ? $setting['title'][$language_id] : '';

        if (isset($this->request->get['manufacturer_id'])) {
            $data['manufacturer_id'] = $this->request->get['manufacturer_id'];
        } else {
            $data['manufacturer_id'] = 0;
        }

        $this->load->model('catalog/manufacturer');

        $data['manufacturers'] = array();

        $results = $this->model_catalog_manufacturer->getManufacturers();

        foreach ($results as $result) {
            $data['manufacturers'][] = array(
                'manufacturer_id' => $result['manufacturer_id'],
                'name'            => $result['name'],
                'href'            => $this->url->link('product/manufacturer/info', 'manufacturer_id=' . $result['manufacturer_id'])
            );
        }

        $data['module'] = $module++;

        return $this->load->view('extension/module/boss_manufacturer', $data);
    }
}
?>