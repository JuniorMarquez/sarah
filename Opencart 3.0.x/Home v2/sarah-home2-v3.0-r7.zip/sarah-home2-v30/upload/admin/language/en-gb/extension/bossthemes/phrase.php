<?php
// Heading Title
$_['heading_title'] = 'Phrase - Boss - Theme Manager';

// Text
$_['text_success'] = 'Success: You have just modified Phrase!';

// Entry
$_['entry_text_save_off']       = 'Save Off';
$_['entry_text_cart']           = 'Cart';
$_['entry_button_column_left']  = 'Button show left sidebar';
$_['entry_button_column_right'] = 'Button show right sidebar';

// Tab

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Phrase!';