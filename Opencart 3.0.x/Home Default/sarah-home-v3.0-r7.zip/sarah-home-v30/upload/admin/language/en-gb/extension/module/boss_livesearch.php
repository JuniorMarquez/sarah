<?php
// Heading
$_['heading_title'] = 'Boss - Live Search';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success']   = 'Success: You have modified Boss - Live Search module!';
$_['text_edit']      = 'Edit Boss - Live Search Module';

// Entry
$_['entry_width']  = 'Image Width';
$_['entry_height'] = 'Image Height';
$_['entry_limit']  = 'Limit';
$_['entry_image']  = 'Show Image';
$_['entry_price']  = 'Show Price';
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Boss - Live Search module!';
$_['error_width']      = 'Width required!';
$_['error_height']     = 'Height required!';
$_['error_limit']      = 'Limit required!';