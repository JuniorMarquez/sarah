<?php
// Heading
$_['text_manufacturer'] = ' --- Please Select --- ';
?>