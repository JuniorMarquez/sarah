<?php  
class ControllerExtensionModuleBossCarousel extends Controller {
	public function index($setting) {
		if(empty($setting)) return;
		static $module = 0;

		$language_id = $this->config->get('config_language_id');

		$data['heading_title'] = ($setting['title'][$language_id]) ? html_entity_decode($setting['title'][$language_id]) : '';
		$data['description'] = ($setting['description'][$language_id]) ? html_entity_decode($setting['description'][$language_id]) : '';

		if(isset($setting['banner_id'])){

			$this->load->model('design/banner');
			$this->load->model('tool/image');

			$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/swiper.min.css');
			$this->document->addScript('catalog/view/javascript/jquery/swiper/js/swiper.jquery.min.js');

			if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css')) {
				$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css');
			} else {
				$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/opencart.css');
			}

			if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_carousel.css')) {
				$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_carousel.css');
			} else {
				$this->document->addStyle('catalog/view/theme/default/stylesheet/bossthemes/boss_carousel.css');
			}

			$data['limit'] = isset($setting['limit']) ? $setting['limit'] : 6;

			$data['banners'] = array();

			$results = $this->model_design_banner->getBanner($setting['banner_id']);

			foreach ($results as $result) {
				if (file_exists(DIR_IMAGE . $result['image'])) {
					$data['banners'][] = array(
						'title' => $result['title'],
						'link'  => $result['link'],
						'image' => $this->model_tool_image->resize($result['image'], isset($setting['image_width']) ? $setting['image_width'] : 80, isset($setting['image_height']) ? $setting['image_height'] : 80)
					);
				}
			}

			$data['img_row'] = (int)$setting['img_row'];
			$data['num_row'] = (int)$setting['num_row'];
			$data['space'] = (int)$setting['space'];
			$data['width'] = (int)$setting['image_width'];
			$data['height'] = (int)$setting['image_height'];
			$data['center'] = $setting['center'];
			$data['auto'] = $setting['auto'];
			$data['time'] = $setting['time'];
			$data['navigation'] = $setting['navigation'];
			$data['nav_position'] = $setting['nav_position'];
			$data['nav_state'] = $setting['nav_state'];
			$data['pagination'] = $setting['pagination'];
			$data['opacity'] = $setting['opacity'];
			$data['effect'] = $setting['effect'];
			$data['direction'] = $setting['direction'];

			$data['full_width'] = ($setting['layout_width'] == 'full-width') ? 1 : 0;

			$data['module'] = $module++;

			return $this->load->view('extension/module/boss_carousel', $data);
		}
	}
}
