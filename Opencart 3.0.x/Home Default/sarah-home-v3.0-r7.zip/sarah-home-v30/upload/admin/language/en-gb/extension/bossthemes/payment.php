<?php
// Heading Title
$_['heading_title'] = 'Payment - Boss - Theme Manager';

// Text
$_['text_success'] = 'Success: You have just modified Payment!';

// Entry
$_['entry_name']       = 'Name';
$_['entry_image']      = 'Image';
$_['entry_icon']       = 'Icon';
$_['entry_link']       = 'Link';
$_['entry_sort_order'] = 'Sort Order';

// Tab

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Payment!';
$_['error_boss_payment'] = 'Payment Name must be between 1 and 128 characters!';