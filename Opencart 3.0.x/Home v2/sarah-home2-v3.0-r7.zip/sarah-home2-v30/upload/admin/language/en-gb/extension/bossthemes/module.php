<?php
// Heading Title
$_['heading_title']				= 'Module - Boss - Theme Manager';

// Text
$_['text_confirm']				= 'Are you sure? All data of this module will be lost!';
$_['text_success']				= 'Success: You have modified modules!';

// Entry

// Column
$_['column_module']				= 'Module name';

// Tab

// Error
$_['error_permission']			= 'Warning: You do not have permission to modify Module!';