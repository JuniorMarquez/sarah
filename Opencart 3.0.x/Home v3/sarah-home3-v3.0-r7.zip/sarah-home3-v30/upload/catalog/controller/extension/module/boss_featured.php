<?php

class ControllerExtensionModuleBossFeatured extends Controller {
	public function index($setting) {

		if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_featured.css')) {
			$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_featured.css');
		} else {
			$this->document->addStyle('catalog/view/theme/default/stylesheet/bossthemes/boss_featured.css');
		}

		$data['mode'] = '';

		$data['slidable'] = (isset($setting['slidable'])) ? (int)$setting['slidable'] : 0;
		$data['center']   = (isset($setting['center'])) ? (int)$setting['center'] : 0;

		if ($data['center']) {
			$data['mode'] = 'center-mode';
		}

		$data['column']                 = (isset($setting['column'])) ? (int)$setting['column'] : 4;
		$data['num_row']                = (isset($setting['num_row'])) ? (int)$setting['num_row'] : 1;
		$data['per_row']                = (isset($setting['per_row'])) ? (int)$setting['per_row'] : 4;
		$data['pagination']             = (isset($setting['pagination'])) ? (int)$setting['pagination'] : 0;
		$data['navigation']             = (isset($setting['navigation'])) ? (int)$setting['navigation'] : 0;
		$data['nav_position']           = (isset($setting['nav_position'])) ? $setting['nav_position'] : 'nav-top';
		$data['nav_state']              = (isset($setting['nav_state'])) ? $setting['nav_state'] : '';
		$data['product_layout']         = (isset($setting['nav_position'])) ? $setting['product_layout'] : 'product-grid';
		$data['skin']                   = (isset($setting['skin'])) ? $setting['skin'] : 'black';
		$data['large_product_position'] = (isset($setting['large_product_position'])) ? $setting['large_product_position'] : 'first';
		$data['sidebar']                = ($setting['style'] == 'sidebar') ? 1 : 0;
		$data['infinite']               = ($data['per_row'] == 0) ? 1 : 0;

		if ($data['infinite']) {
			$data['mode'] = 'infinite-mode';
		}

		$data['banner_left']  = (!empty($setting['banner_left']['image'])) ? $setting['banner_left'] : array();
		$data['banner_right'] = (!empty($setting['banner_right']['image'])) ? $setting['banner_right'] : array();

		if ($setting['slidable']) {
			$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/swiper.min.css');
			$this->document->addScript('catalog/view/javascript/jquery/swiper/js/swiper.jquery.min.js');

			if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css')) {
				$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css');
			} else {
				$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/opencart.css');
			}
		}

		static $module = 0;

		$language_id = $this->config->get('config_language_id');

		$text_save_off         = $this->config->get('boss_phrase_text_save_off');
		$data['text_save_off'] = (isset($text_save_off[$language_id])) ? $text_save_off[$language_id] : '';

		$data['template'] = $this->config->get('theme_' . $this->config->get('config_theme') . '_directory');

		$data['heading_title'] = isset($setting['title'][$language_id]) ? html_entity_decode($setting['title'][$language_id]) : '';
		$data['description']   = isset($setting['description'][$language_id]) ? html_entity_decode($setting['description'][$language_id]) : '';

		$data['box_class_css'] = isset($setting['class_css']) ? $setting['class_css'] : 'none-class';

		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$mainproduct    = array();
		$data['images'] = array();

		$products = array();

		if (isset($setting['large_product']) && $setting['large_product']) {
			if (isset($setting['product_id'])) {
				$product_id = $setting['product_id'];
			}

			$product_info = $this->model_catalog_product->getProduct($product_id);

			if (isset($setting['img_width'])) {
				$img_width = $setting['img_width'];
			} else {
				$img_width = 380;
			}

			if (isset($setting['img_height'])) {
				$img_height = $setting['img_height'];
			} else {
				$img_height = 380;
			}

			if (!empty($product_info)) {
				if ($product_info['image']) {
					$image = $this->model_tool_image->resize($product_info['image'], $img_width, $img_height);
				} else {
					$image = false;
				}

				if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($product_info['price'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$product_info['special']) {
					$special = $this->currency->format($this->tax->calculate($product_info['special'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = $product_info['rating'];
				} else {
					$rating = false;
				}

				$mainproduct = array(
					'product_id'  => $product_info['product_id'],
					'thumb'       => $image,
					'name'        => $product_info['name'],
					'description' => ((int)$setting['description_length'] <= 0) ? '' : utf8_substr(strip_tags(html_entity_decode($product_info['description'], ENT_QUOTES, 'UTF-8')), 0, $setting['description_length']) . '..',
					'price'       => $price,
					'special'     => $special,
					'saving'      => sprintf($data['text_save_off'], ($product_info['price'] == 0) ? 100 : round((($product_info['price'] - $product_info['special']) / $product_info['price']) * 100, 0)),
					'minimum'     => $product_info['minimum'],
					'rating'      => $rating,
					'href'        => $this->url->link('product/product', 'product_id=' . $product_info['product_id']),
				);
			}

			if ($data['product_layout'] == 'product-grid') {
				$data['phase_1']    = (($data['column'] - 1) * 2);
				$data['col_large'] = $data['column'];
				$data['col_phase']  = ($data['column'] / ($data['column'] - 1));
			} else {
				$data['phase_1']    = ($data['column'] - 1);
				$data['col_large'] = $data['column'];
				$data['col_phase']  = ($data['column'] / ($data['column'] - 1));
			}
		}

		if (isset($setting['limit'])) {
			$limit = $setting['limit'];
		} else {
			$limit = 8;
		}

		if ($setting['type_product'] == "popular") {
			$results = $this->model_catalog_product->getPopularProducts($limit);
		} elseif ($setting['type_product'] == "special") {
			$data_sort = array(
				'sort'  => 'pd.name',
				'order' => 'ASC',
				'start' => 0,
				'limit' => $limit,
			);
			$results   = $this->model_catalog_product->getProductSpecials($data_sort);
		} elseif ($setting['type_product'] == "best_seller") {
			$results = $this->model_catalog_product->getBestSellerProducts($limit);
		} elseif ($setting['type_product'] == "latest") {
			$results = $this->model_catalog_product->getLatestProducts($limit);
		} elseif ($setting['type_product'] == "category") {
			$data_sort = array(
				'filter_category_id' => $setting['category_id'],
				'sort'               => 'pd.name',
				'order'              => 'ASC',
				'start'              => 0,
				'limit'              => $limit,
			);
			$results   = $this->model_catalog_product->getProducts($data_sort);
		} elseif ($setting['type_product'] == "featured") {
			if (isset($setting['product_featured'])) {
				$pros_id = $setting['product_featured'];
			} else {
				$pros_id = array();
			}

			if (!empty($pros_id)) {
				foreach ($pros_id as $product_id) {
					$product_info = $this->model_catalog_product->getProduct($product_id);

					if ($product_info) {
						$results[$product_id] = $product_info;
					}
				}
			}
		} elseif ($setting['type_product'] == "related") {
			if (isset($this->request->get['product_id'])) {
				$results = $this->model_catalog_product->getProductRelated((int)$this->request->get['product_id']);
			}
		}

		if (!empty($results)) {

			if (isset($setting['image_width'])) {
				$image_width = $setting['image_width'];
			} else {
				$image_width = 200;
			}

			if (isset($setting['image_height'])) {
				$image_height = $setting['image_height'];
			} else {
				$image_height = 200;
			}

			foreach ($results as $result) {
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $image_width, $image_height);
				} else {
					$image = false;
				}

				if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);

					$money_save_original = $result['price'] - $result['special'];
					$percent             = round((float)($money_save_original / $result['price'] * 100), 0);
				} else {
					$special = false;
					$percent = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = $result['rating'];
				} else {
					$rating = false;
				}

				$products[] = array(
					'product_id'  => $result['product_id'],
					'percent'     => $percent,
					'thumb'       => $image,
					'name'        => $result['name'],
					'description' => ((int)$setting['description_length'] <= 0) ? '' : utf8_substr(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')), 0, $setting['description_length']) . '..',
					'price'       => $price,
					'special'     => $special,
					'saving'      => sprintf($data['text_save_off'], ($result['price'] == 0) ? 100 : round((($result['price'] - $result['special']) / $result['price']) * 100, 0)),
					'minimum'     => $result['minimum'],
					'rating'      => $rating,
					'href'        => $this->url->link('product/product', 'product_id=' . $result['product_id']),
				);
			}
		}

		if (isset($image_width)) {
			$data['image_width'] = $image_width;
		} else {
			$data['image_width'] = 200;
		}

		$data['product_data'] = array(
			'products'    => $products,
			'mainproduct' => $mainproduct,
		);

		$data['module'] = $module++;

		return $this->load->view('extension/module/boss_featured', $data);
	}
}