<?php
// Heading
$_['heading_title'] = 'Blog Search';
$_['text_search'] = 'Search';
?>