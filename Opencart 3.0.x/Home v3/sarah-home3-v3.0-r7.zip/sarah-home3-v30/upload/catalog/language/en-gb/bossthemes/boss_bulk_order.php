<?php
// Heading
$_['heading_title'] 	= 'Bulk Order';
$_['text_heading_title'] 	= 'Bulk Order';

// entry
$_['entry_category'] 		= 'Categories';
$_['entry_name'] 		= 'Product name';
$_['entry_image'] 		= 'Image';
$_['entry_model'] 	= 'Model';
$_['entry_price'] 		= 'Price';
$_['entry_tag'] 		= 'Tag';
$_['text_error']    = 'The page you requested cannot be found.';
$_['text_price_range']    = 'Price Range';
$_['text_price']    = 'Price';
$_['text_filter']    = 'FILTER';

//text
$_['text_empty']        = 'There are NOT products.';
$_['text_category']        = 'All Categories';
$_['text_tax']                 = 'Ex Tax:';
// button
$_['button_filter'] 		= 'Filter';
$_['button_continue'] 		= 'Continue';
?>