<?php
// Heading
$_['heading_title']     = 'RSS Boss Blog';

$_['text_rss_blog_categories']     = 'RSS Blog Categories';
$_['text_blogrss']     = 'RSS Blog';

?>