<?php
class ControllerExtensionModuleBossTopcategory extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/boss_topcategory');
        $_languages = $this->language->all();
        $data = (isset($data)) ? array_merge($data, $_languages) : $_languages;

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/module');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

            if (!isset($this->request->get['module_id'])) {
                $this->model_setting_module->addModule('boss_topcategory', $this->request->post);
            } else {
                $this->model_setting_module->editModule($this->request->get['module_id'], $this->request->post);
            }
            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }

        //select

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['name'])) {
            $data['error_name'] = $this->error['name'];
        } else {
            $data['error_name'] = '';
        }

        if (isset($this->error['width'])) {
            $data['error_image_width'] = $this->error['width'];
        } else {
            $data['error_image_width'] = '';
        }

        if (isset($this->error['height'])) {
            $data['error_image_height'] = $this->error['height'];
        } else {
            $data['error_image_height'] = '';
        }

		if (isset($this->error['num_row'])) {
			$data['error_num_row'] = $this->error['num_row'];
		} else {
			$data['error_num_row'] = '';
		}

        if (isset($this->error['per_row'])) {
			$data['error_per_row'] = $this->error['per_row'];
		} else {
			$data['error_per_row'] = '';
		}

        if (isset($this->error['category'])) {
            $data['error_category'] = $this->error['category'];
        } else {
            $data['error_category'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
            'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], true),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_module'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true),
            'separator' => ' :: '
        );

        if (!isset($this->request->get['module_id'])) {
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/banner', 'user_token=' . $this->session->data['user_token'], true)
            );
        } else {
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/boss_topcategory', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true)
            );
        }

        if (!isset($this->request->get['module_id'])) {
            $data['action'] = $this->url->link('extension/module/boss_topcategory', 'user_token=' . $this->session->data['user_token'], true);
        } else {
            $data['action'] = $this->url->link('extension/module/boss_topcategory', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true);
        }

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
            $module_info = $this->model_setting_module->getModule($this->request->get['module_id']);
        }

        if (isset($this->request->post['name'])) {
            $data['name'] = $this->request->post['name'];
        } elseif (!empty($module_info)) {
            $data['name'] = $module_info['name'];
        } else {
            $data['name'] = '';
        }

        if (isset($this->request->post['title'])) {
            $data['title'] = $this->request->post['title'];
        } elseif (!empty($module_info)) {
            $data['title'] = $module_info['title'];
        } else {
            $data['title'] = '';
        }

        if (isset($this->request->post['image_width'])) {
            $data['image_width'] = $this->request->post['image_width'];
        } elseif (!empty($module_info)) {
            $data['image_width'] = $module_info['image_width'];
        } else {
            $data['image_width'] = '';
        }

        if (isset($this->request->post['image_height'])) {
            $data['image_height'] = $this->request->post['image_height'];
        } elseif (!empty($module_info)) {
            $data['image_height'] = $module_info['image_height'];
        } else {
            $data['image_height'] = '';
        }

        if (isset($this->request->post['style'])) {
            $data['style'] = $this->request->post['style'];
        } elseif (!empty($module_info)) {
            $data['style'] = $module_info['style'];
        } else {
            $data['style'] = '';
        }

		if (isset($this->request->post['column'])) {
			$data['column'] = $this->request->post['column'];
		} elseif (!empty($module_info)) {
			$data['column'] = $module_info['column'];
		} else {
			$data['column'] = 4;
		}

		if (isset($this->request->post['num_row'])) {
			$data['num_row'] = $this->request->post['num_row'];
		} elseif (!empty($module_info)) {
			$data['num_row'] = $module_info['num_row'];
		} else {
			$data['num_row'] = '';
		}

        if (isset($this->request->post['per_row'])) {
            $data['per_row'] = $this->request->post['per_row'];
        } elseif (!empty($module_info)) {
            $data['per_row'] = $module_info['per_row'];
        } else {
            $data['per_row'] = '';
        }

		if (isset($this->request->post['skin'])) {
			$data['skin'] = $this->request->post['skin'];
		} elseif (!empty($module_info)) {
			$data['skin'] = $module_info['skin'];
		} else {
			$data['skin'] = '';
		}

        if (isset($this->request->post['status'])) {
            $data['status'] = $this->request->post['status'];
        } elseif (!empty($module_info)) {
            $data['status'] = $module_info['status'];
        } else {
            $data['status'] = '';
        }

        $this->load->model('catalog/category');

        if (isset($this->request->post['top_category'])) {
            $top_category = $this->request->post['top_category'];
        } elseif (!empty($module_info['top_category'])) {
            $top_category = $module_info['top_category'];
        } else {
            $top_category = array();
        }

        $data['categories'] = array();

        $results = $this->model_catalog_category->getCategories(0);

        foreach ($results as $result) {
            $select = 0;
            if(in_array($result['category_id'], $top_category )){
                $select = 1;
            }
            $data['categories'][] = array(
                'category_id' => $result['category_id'],
                'name'        => $result['name'],
                'selected'    => $select
            );

        }

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/boss_topcategory', $data));
    }

    private function validate() {

        if (!$this->user->hasPermission('modify', 'extension/module/boss_topcategory')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
            $this->error['name'] = $this->language->get('error_name');
        }

        if (!(int)$this->request->post['image_width'] && $this->request->post['style'] != 'masonry') {
            $this->error['width'] = $this->language->get('error_image_width');
        }

        if (!(int)$this->request->post['image_height'] && $this->request->post['style'] != 'masonry') {
            $this->error['height'] = $this->language->get('error_image_height');
        }

        if(!isset($this->request->post['top_category'])){
            $this->error['category'] = $this->language->get('error_category');
        }

		if (!(int)$this->request->post['num_row']) {
			$this->error['num_row'] = $this->language->get('error_num_row');
		}

		if (!(int)$this->request->post['per_row']) {
			$this->error['per_row'] = $this->language->get('error_per_row');
		}

        return !$this->error;
    }

}