<?php

class ControllerExtensionModuleBossTopcategory extends Controller {
	public function index($setting) {
		if (empty($setting)) return;

		static $module = 0;

		$language_id = (int)$this->config->get('config_language_id');

		if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_topcategory.css')) {
			$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_topcategory.css');
		} else {
			$this->document->addStyle('catalog/view/theme/default/stylesheet/bossthemes/boss_topcategory.css');
		}

		$_language = new Language($this->config->get('config_language'));
		$_language->load('extension/module/boss_topcategory');
		$data = (isset($data)) ? array_merge($data, $_language->all()) : $_language->all();

		$data['per_row']       = (isset($setting['per_row'])) ? $setting['per_row'] : 3;
		$data['num_row']       = (isset($setting['num_row'])) ? $setting['num_row'] : 1;
		$data['column']        = (isset($setting['column'])) ? $setting['column'] : 4;
		$data['image_width']   = (isset($setting['image_width'])) ? $setting['image_width'] : 200;
		$data['image_height']  = (isset($setting['image_height'])) ? $setting['image_height'] : 200;
		$data['style']         = (isset($setting['style'])) ? $setting['style'] : 'static';
		$data['heading_title'] = (isset($setting['title'][$language_id])) ? html_entity_decode($setting['title'][$language_id]) : '';
		$data['skin']          = (isset($setting['skin'])) ? $setting['skin'] : 'black';

		if ($data['style'] == 'slide') {
			$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/swiper.min.css');
			$this->document->addScript('catalog/view/javascript/jquery/swiper/js/swiper.jquery.min.js');

			if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css')) {
				$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css');
			} else {
				$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/opencart.css');
			}
		}

		if ($data['style'] == 'masonry') {
			$this->document->addScript('catalog/view/javascript/bossthemes/masonry.pkgd.min.js');
		}

		$this->load->model('catalog/category');
		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$data['categories'] = array();

		if (isset($setting['top_category'])) {
			$categories = $setting['top_category'];

			foreach ($categories as $category_id) {
				$filter_data = array(
					'filter_category_id'  => $category_id,
					'filter_sub_category' => true,
				);

				$category_info = $this->model_catalog_category->getCategory($category_id);

				if ($category_info) {
					if ($category_info['image']) {
						$image = ($data['style'] == 'masonry') ? ('image/' . $category_info['image']) : ($this->model_tool_image->resize($category_info['image'], $data['image_width'], $data['image_height']));
					} else {
						$image = false;
					}

					$data['categories'][] = array(
						'title'      => $category_info['name'],
						'count'      => ($this->config->get('config_product_count')) ? $this->model_catalog_product->getTotalProducts($filter_data) : 0,
						'href'       => $this->url->link('product/category', 'path=' . $category_id),
						'image'      => $image,
						'sort_order' => $category_info['sort_order'],
					);
				}
			}
		}

		$sort_order = array();

		foreach ($data['categories'] as $key => $value) {
			$sort_order[$key] = $value['sort_order'];
		}

		array_multisort($sort_order, SORT_ASC, $data['categories']);

		$data['module'] = $module++;

		return $this->load->view('extension/module/boss_topcategory', $data);
	}
}

?>