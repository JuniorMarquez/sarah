<?php
// Heading
$_['heading_title'] = 'Blog Categories';
$_['text_bosblog'] = 'Blog';
?>