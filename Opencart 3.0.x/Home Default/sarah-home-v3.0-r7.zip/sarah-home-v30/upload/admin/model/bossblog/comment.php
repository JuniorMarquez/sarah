<?php
class ModelBossblogComment extends Model {
	public function addComment($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "blog_comment SET author = '" . $this->db->escape($data['author']) . "', blog_article_id = '" . $this->db->escape($data['blog_article_id']) . "', text = '" . $this->db->escape(strip_tags($data['text'])) . "',  email = '" . $this->db->escape($data['email']) . "', status = '" . (int)$data['status'] . "', date_added = NOW()");
	
		$this->cache->delete('blog_article');
	}
	
	public function editComment($blog_comment_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "blog_comment SET author = '" . $this->db->escape($data['author']) . "', blog_article_id = '" . $this->db->escape($data['blog_article_id']) . "', text = '" . $this->db->escape(strip_tags($data['text'])) . "',  email = '" . $this->db->escape($data['email']) . "', status = '" . (int)$data['status'] . "', date_modified = NOW() WHERE blog_comment_id = '" . (int)$blog_comment_id . "'");
	
		$this->cache->delete('blog_article');
	}
	
	public function deleteComment($blog_comment_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "blog_comment WHERE blog_comment_id = '" . (int)$blog_comment_id . "'");
		
		$this->cache->delete('blog_article');
	}
	
	public function getComment($blog_comment_id) {
		$query = $this->db->query("SELECT DISTINCT *, (SELECT bad.name FROM " . DB_PREFIX . "blog_article_description bad WHERE bad.blog_article_id = bc.blog_article_id AND bad.language_id = '" . (int)$this->config->get('config_language_id') . "') AS article FROM " . DB_PREFIX . "blog_comment bc WHERE bc.blog_comment_id = '" . (int)$blog_comment_id . "'");
		
		return $query->row;
	}

	public function getComments($data = array()) {
		$sql = "SELECT bc.blog_comment_id, bad.name, bc.author, bc.email, bc.text, bc.status, bc.date_added FROM " . DB_PREFIX . "blog_comment bc LEFT JOIN " . DB_PREFIX . "blog_article_description bad ON (bc.blog_article_id = bad.blog_article_id) WHERE bad.language_id = '" . (int)$this->config->get('config_language_id') . "'";																																					  
		
		$sort_data = array(
			'bad.name',
			'bc.author',
			'bc.email',
            'bc.text',
			'bc.status',
			'bc.date_added'
		);	
			
		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];	
		} else {
			$sql .= " ORDER BY bc.date_added";	
		}
			
		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}			

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}	
			
			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}																																							  
																																							  
		$query = $this->db->query($sql);																																				
		
		return $query->rows;	
	}
	
	public function getTotalComments() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog_comment");
		
		return $query->row['total'];
	}
	
	public function getTotalCommentsAwaitingApproval() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog_comment WHERE status = '0'");
		
		return $query->row['total'];
	}	
    
    public function checkBlogComment() {       
		$db_file = __DIR__ . '/blog_comment.sql';
		if (file_exists($db_file)) {
			$lines = file($db_file);
			
			$templine = '';
			foreach ($lines as $line){
				if (substr($line, 0, 2) == '--' || $line == '')
					continue;
				$templine .= $line;
				if (substr(trim($line), -1, 1) == ';'){
					$this->db->query(str_replace('oc_', DB_PREFIX, $templine));
					$templine = '';
				}
			}
		}
	}	
}