<?php
// Heading Title
$_['heading_title']				= 'Custom - Boss - Theme Manager';

// Text
$_['text_success']				= 'Success: You have just modified Custom!';

// Entry
$_['entry_status']				= 'Status';
$_['entry_content']				= 'Content';

// Tab
$_['tab_welcome']				= 'Welcome';
$_['tab_javascript']			= 'Javascript';
$_['tab_css']					= 'CSS';

// Error
$_['error_permission']			= 'Warning: You do not have permission to modify Custom!';