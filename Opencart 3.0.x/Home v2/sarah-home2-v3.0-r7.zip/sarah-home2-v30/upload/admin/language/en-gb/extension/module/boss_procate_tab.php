<?php
// Heading
$_['heading_title']         = 'Boss - Products Category Tabs';
$_['text_extension']        = 'Extensions';
$_['text_content']          = 'Content style';
$_['text_sidebar']          = 'Sidebar style';
$_['entry_title']           = 'More Detail Text';
$_['text_get_product']      = 'Get product from';
$_['text_top']              = 'Top';
$_['text_top_left']         = 'Top Left';
$_['text_top_right']        = 'Top Right';
$_['text_middle']           = 'Middle';
$_['text_bottom']           = 'Bottom';
$_['text_bottom_left']      = 'Bottm Left';
$_['text_bottom_right']     = 'Bottm Right';
$_['text_top_bottom_left']  = 'Top Bottom Left';
$_['text_top_bottom_right'] = 'Top Bottom Right';
$_['text_visible']          = 'Visible';
$_['text_invisible']        = 'Invisible';
$_['text_list']             = 'List';
$_['text_grid']             = 'Grid';
$_['text_red']              = 'Red';
$_['text_orange']           = 'Orange';
$_['text_yellow']           = 'Yellow';
$_['text_green']            = 'Green';
$_['text_blue']             = 'Blue';
$_['text_teal']             = 'Teal';
$_['text_pink']             = 'Pink';
$_['text_purple']           = 'Purple';
$_['text_black']            = 'Black';
$_['text_popular']          = 'Popular';
$_['text_special']          = 'Special';
$_['text_lastest']          = 'Lastest';
$_['text_rating']           = 'Rating';
$_['text_best_seller']      = 'Best Seller';
$_['text_normal']           = 'Normal';
$_['text_large_horizontal'] = 'Large Horizontal';
$_['text_large_vertical']   = 'Large Vertical';

// Entry
$_['entry_image_size']         = 'Image (W x H)';
$_['entry_description']        = 'Description';
$_['entry_name']               = 'Name';
$_['entry_status']             = 'Status';
$_['entry_limit']              = 'Limit';
$_['entry_description_length'] = 'Description length';
$_['entry_img_large']          = 'Image large size (WxH)';
$_['entry_filter']             = 'Filter';
$_['entry_slide']              = 'Slidable';
$_['entry_num_row']            = 'Number Row';
$_['entry_per_row']            = 'Product per Row';
$_['entry_navigation']         = 'Navigation';
$_['entry_nav_position']       = 'Navigation Position';
$_['entry_nav_state']          = 'Navigation State';
$_['entry_pagination']         = 'Pagination';
$_['entry_center']             = 'Center Mode';
$_['entry_position']           = 'Position';
$_['entry_product_layout']     = 'Product Layout';
$_['entry_style']              = 'Style';
$_['entry_skin']               = 'Skin';
$_['entry_column']             = 'Column';
$_['entry_category']           = 'Category';
$_['entry_title']              = 'Title';
$_['entry_description']        = 'Description';
$_['entry_custom_status']      = 'Status';
$_['entry_custom_style']       = 'Style';
$_['entry_custom']             = 'Content';

// Tab
$_['tab_slide']  = 'Slidable';
$_['tab_tab']    = 'Tab';
$_['tab_custom'] = 'Custom';

// Message
$_['text_success'] = 'Saved successly!';

// Error 
$_['error_permission'] = 'Warning: You do not have permission to modify module Boss - Products Category Tabss!';
$_['error_image']      = 'Image width &amp; height dimensions required!';
$_['error_category']   = 'Category required!';
$_['error_numproduct'] = 'Number of products required!';
$_['error_row']        = 'Row number required!';
