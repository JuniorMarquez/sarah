<?php

class ControllerExtensionModuleBossProcateTab extends Controller {
	public function index($setting) {
		static $module = 0;

		if (empty($setting['category_id']) && empty($setting['tab'])) {
			return NULL;
		}

		if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_procate_tab.css')) {
			$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_procate_tab.css');
		} else {
			$this->document->addStyle('catalog/view/theme/default/stylesheet/bossthemes/boss_procate_tab.css');
		}

		$language_id        = $this->config->get('config_language_id');
		$category_id        = (!empty($setting['category_id'])) ? (int)$setting['category_id'] : 0;
		$image_width        = (!empty($setting['image_width'])) ? (int)$setting['image_width'] : 450;
		$image_height       = (!empty($setting['image_height'])) ? (int)$setting['image_height'] : 450;
		$description_length = (!empty($setting['description_length'])) ? (int)$setting['description_length'] : 108;
		$limit              = (!empty($setting['limit'])) ? (int)$setting['limit'] : 8;
		$text_save_off      = $this->config->get('boss_phrase_text_save_off');

		$data['text_save_off']  = (isset($text_save_off[$language_id])) ? $text_save_off[$language_id] : '';
		$data['heading_title']  = (isset($setting['title'][$language_id])) ? html_entity_decode($setting['title'][$language_id]) : '';
		$data['description']    = (isset($setting['description'][$language_id])) ? html_entity_decode($setting['description'][$language_id]) : '';
		$data['custom']         = (isset($setting['custom'][$language_id])) ? html_entity_decode($setting['custom'][$language_id]) : '';
		$data['custom_status']  = (isset($setting['custom_status'])) ? (int)$setting['custom_status'] : 0;
		$data['custom_style']   = (isset($setting['custom_style'])) ? $setting['custom_style'] : 'normal';
		$data['column']         = (isset($setting['column'])) ? (int)$setting['column'] : 4;
		$data['num_row']        = (isset($setting['num_row'])) ? (int)$setting['num_row'] : 1;
		$data['per_row']        = (isset($setting['per_row'])) ? (int)$setting['per_row'] : 4;
		$data['pagination']     = (isset($setting['pagination'])) ? (int)$setting['pagination'] : 0;
		$data['navigation']     = (isset($setting['navigation'])) ? (int)$setting['navigation'] : 0;
		$data['nav_position']   = (isset($setting['nav_position'])) ? $setting['nav_position'] : 'nav-top';
		$data['nav_state']      = (isset($setting['nav_state'])) ? $setting['nav_state'] : '';
		$data['product_layout'] = (isset($setting['nav_position'])) ? $setting['product_layout'] : 'product-grid';
		$data['skin']           = (isset($setting['skin'])) ? $setting['skin'] : 'black';
		$data['sidebar']        = ($setting['style'] == 'sidebar') ? 1 : 0;

		if ($data['custom_status']) {
			if ($data['custom_style'] == 'large-v') {
				$data['phase_1']    = (($data['column'] - 1) * 2);
				$data['col_custom'] = $data['column'];
				$data['col_phase']  = ($data['column'] / ($data['column'] - 1));
			} elseif ($data['custom_style'] == 'large-h') {
				$data['phase_1'] = ($data['column'] / 2);

				if ($data['phase_1'] <= 1) {
					$data['phase_1']    = 0;
					$data['col_custom'] = 1;
					$data['col_phase']  = 1;
				} else {
					$data['col_custom'] = 2;
					$data['col_phase']  = 2;
				}
			} else {
				$data['phase_1']    = ($data['column'] - 1);
				$data['col_custom'] = $data['column'];
				$data['col_phase']  = ($data['column'] / ($data['column'] - 1));
			}
		}

		$data['slidable']
			= (isset($setting['slidable'])) ? (int)$setting['slidable'] : 0;

		if ($setting['slidable']) {
			$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/swiper.min.css');
			$this->document->addScript('catalog/view/javascript/jquery/swiper/js/swiper.jquery.min.js');

			if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css')) {
				$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css');
			} else {
				$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/opencart.css');
			}
		}

		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$data['tabs'] = array();

		foreach ($setting['tab'] as $tab) {
			$results = array();

			if ($tab['filter'] == 'popular') {
				$results = $this->getPopularProducts($category_id, $limit);
			} elseif ($tab['filter'] == 'special') {
				$results = $this->getProductSpecials($category_id, $limit);
			} elseif ($tab['filter'] == 'lastest') {
				$results = $this->getLatestProducts($category_id, $limit);
			} elseif ($tab['filter'] == 'rating') {
				$results = $this->getMostRatingProducts($category_id, $limit);
			} elseif ($tab['filter'] == 'best_seller') {
				$results = $this->getBestSellerProducts($category_id, $limit);
			}

			$products = array();

			foreach ($results as $result) {
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $image_width, $image_height);
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $image_width, $image_height);
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = (int)$result['rating'];
				} else {
					$rating = false;
				}

				$products[] = array(
					'product_id'  => $result['product_id'],
					'thumb'       => $image,
					'name'        => $result['name'],
					'description' => ((int)$description_length) ? utf8_substr(trim(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8'))), 0, (int)$description_length) . '..' : '',
					'price'       => $price,
					'special'     => $special,
					'saving'      => sprintf($data['text_save_off'], ($result['price'] == 0) ? 100 : round((($result['price'] - $result['special']) / $result['price']) * 100, 0)),
					'tax'         => $tax,
					'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
					'rating'      => $rating,
					'href'        => $this->url->link('product/product', 'product_id=' . $result['product_id']),
				);
			}

			$data['tabs'][] = array(
				'name'     => (isset($tab['name'][$language_id])) ? $tab['name'][$language_id] : '',
				'products' => $products,
			);
		}

		$data['module'] = $module++;

		return $this->load->view('extension/module/boss_procate_tab', $data);
	}

	public
	function getProductSpecials($category_id, $limit) {
		$product_data = $this->cache->get('product.special.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit);

		if (!$product_data) {
			$product_data = array();

			$query = $this->db->query("SELECT DISTINCT ps.product_id, (SELECT AVG(rating) FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = ps.product_id AND r1.status = '1' GROUP BY r1.product_id) AS rating FROM " . DB_PREFIX . "product_special ps LEFT JOIN " . DB_PREFIX . "product p ON (ps.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.date_available <= NOW() AND p2c.category_id = '" . (int)$category_id . "' AND p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' AND ps.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) GROUP BY ps.product_id ORDER BY p.price ASC LIMIT 0," . $limit);

			foreach ($query->rows as $result) {
				$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
			}

			$this->cache->set('product.special.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit, $product_data);
		}

		return $product_data;
	}

	public
	function getLatestProducts($category_id, $limit) {
		$product_data = $this->cache->get('product.latest.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit);

		if (!$product_data) {
			$product_data = array();

			$query = $this->db->query("SELECT p.product_id FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.date_available <= NOW() AND p2c.category_id = '" . (int)$category_id . "' AND p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' ORDER BY p.date_added DESC LIMIT " . (int)$limit);

			foreach ($query->rows as $result) {
				$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
			}

			$this->cache->set('product.latest.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit, $product_data);
		}

		return $product_data;
	}

	public
	function getPopularProducts($category_id, $limit) {
		$product_data = $this->cache->get('product.popular.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit);

		if (!$product_data) {
			$product_data = array();

			$query = $this->db->query("SELECT p.product_id FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.date_available <= NOW() AND p2c.category_id = '" . (int)$category_id . "' AND p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' ORDER BY p.viewed DESC, p.date_added DESC LIMIT " . (int)$limit);

			foreach ($query->rows as $result) {
				$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
			}

			$this->cache->set('product.popular.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit, $product_data);
		}

		return $product_data;
	}

	public
	function getBestSellerProducts($category_id, $limit) {
		$product_data = $this->cache->get('product.bestseller.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit);

		if (!$product_data) {
			$product_data = array();

			$query = $this->db->query("SELECT op.product_id, SUM(op.quantity) AS total FROM " . DB_PREFIX . "order_product op LEFT JOIN `" . DB_PREFIX . "order` o ON (op.order_id = o.order_id) LEFT JOIN `" . DB_PREFIX . "product` p ON (op.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) WHERE o.order_status_id > '0' AND p.status = '1' AND p.date_available <= NOW() AND p2c.category_id = '" . (int)$category_id . "' AND p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' GROUP BY op.product_id ORDER BY total DESC LIMIT " . (int)$limit);

			foreach ($query->rows as $result) {
				$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
			}

			$this->cache->set('product.bestseller.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit, $product_data);
		}

		return $product_data;
	}

	public
	function getMostRatingProducts($category_id, $limit) {
		$product_data = $this->cache->get('product.most-rating.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit);

		if (!$product_data) {
			$product_data = array();

			$query = $this->db->query("SELECT p.product_id, (SELECT AVG(rating) AS total FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = p.product_id AND r1.status = '1' GROUP BY r1.product_id) AS rating FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) WHERE p.status = '1' AND p.date_available <= NOW() AND p2c.category_id = '" . (int)$category_id . "' AND p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' ORDER BY rating DESC LIMIT " . (int)$limit);

			foreach ($query->rows as $result) {
				$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
			}

			$this->cache->set('product.most-rating.' . (int)$this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id') . '.' . $this->config->get('config_customer_group_id') . '.' . (int)$category_id . '.' . (int)$limit, $product_data);
		}

		return $product_data;
	}
}