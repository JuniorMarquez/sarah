
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `oc_megamenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_megamenu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `icon` varchar(225) DEFAULT NULL,
  `label_color` varchar(255) DEFAULT NULL,
  `num_column` int(2) unsigned DEFAULT '1',
  `icon_class` varchar(255) DEFAULT NULL,
  `icon_class_status` tinyint(1) NOT NULL DEFAULT '1',
  `module_id` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `oc_megamenu` DISABLE KEYS */;
INSERT INTO `oc_megamenu` VALUES (1,1,1,'index.php','','',1,'',0,129),(2,1,3,'index.php?route=bossthemes/boss_bulk_order','','',1,'',0,129),(3,1,4,'index.php?route=bossthemes/boss_testimonial','','',1,'',0,129),(4,1,5,'index.php?route=bossblog/bossblog','','',1,'',0,129),(5,1,2,'index.php?route=product/category&amp;path=20','','',3,'',0,129),(6,1,6,'index.php?route=information/contact','','',1,'',0,129);
/*!40000 ALTER TABLE `oc_megamenu` ENABLE KEYS */;
DROP TABLE IF EXISTS `oc_megamenu_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_megamenu_column` (
  `column_id` int(11) NOT NULL AUTO_INCREMENT,
  `row_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `num_column` int(2) unsigned NOT NULL DEFAULT '1',
  `type` varchar(255) DEFAULT NULL,
  `params` text,
  PRIMARY KEY (`column_id`,`row_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `oc_megamenu_column` DISABLE KEYS */;
INSERT INTO `oc_megamenu_column` VALUES (1,1,2,1,1,'category','{\"category_id\":\"20\",\"product_img_w\":\"\",\"product_img_h\":\"\",\"manufacturer_img_w\":\"\",\"manufacturer_img_h\":\"\",\"manufacturer_name\":\"0\",\"content_text\":{\"1\":\"\",\"2\":\"\"}}'),(2,1,3,1,1,'category','{\"category_id\":\"18\",\"product_img_w\":\"\",\"product_img_h\":\"\",\"manufacturer_img_w\":\"\",\"manufacturer_img_h\":\"\",\"manufacturer_name\":\"0\",\"content_text\":{\"1\":\"\",\"2\":\"\"}}'),(3,1,1,1,1,'category','{\"category_id\":\"25\",\"product_img_w\":\"\",\"product_img_h\":\"\",\"manufacturer_img_w\":\"\",\"manufacturer_img_h\":\"\",\"manufacturer_name\":\"0\",\"content_text\":{\"1\":\"\",\"2\":\"\"}}'),(4,2,0,1,1,'category','{\"category_id\":\"57\",\"product_img_w\":\"\",\"product_img_h\":\"\",\"manufacturer_img_w\":\"\",\"manufacturer_img_h\":\"\",\"manufacturer_name\":\"0\",\"content_text\":{\"1\":\"\",\"2\":\"\"}}'),(5,2,0,1,1,'category','{\"category_id\":\"17\",\"product_img_w\":\"\",\"product_img_h\":\"\",\"manufacturer_img_w\":\"\",\"manufacturer_img_h\":\"\",\"manufacturer_name\":\"0\",\"content_text\":{\"1\":\"\",\"2\":\"\"}}'),(6,2,0,1,1,'category','{\"category_id\":\"33\",\"product_img_w\":\"\",\"product_img_h\":\"\",\"manufacturer_img_w\":\"\",\"manufacturer_img_h\":\"\",\"manufacturer_name\":\"0\",\"content_text\":{\"1\":\"\",\"2\":\"\"}}');
/*!40000 ALTER TABLE `oc_megamenu_column` ENABLE KEYS */;
DROP TABLE IF EXISTS `oc_megamenu_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_megamenu_description` (
  `menu_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `oc_megamenu_description` DISABLE KEYS */;
INSERT INTO `oc_megamenu_description` VALUES (1,1,'Home',''),(1,2,'Home',''),(2,1,'Bulk Orders',''),(2,2,'Bulk Orders',''),(3,1,'Testimonial',''),(3,2,'Testimonial',''),(4,1,'Blog',''),(4,2,'Blog',''),(5,1,'Products',''),(5,2,'Products',''),(6,1,'Contact',''),(6,2,'Contact','');
/*!40000 ALTER TABLE `oc_megamenu_description` ENABLE KEYS */;
DROP TABLE IF EXISTS `oc_megamenu_row`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_megamenu_row` (
  `row_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `height` decimal(10,0) DEFAULT NULL,
  `bg_color` varchar(255) DEFAULT NULL,
  `bg_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`row_id`,`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `oc_megamenu_row` DISABLE KEYS */;
INSERT INTO `oc_megamenu_row` VALUES (1,5,2,1,0,'','catalog/bt_description/bg-menu-shop.jpg');
/*!40000 ALTER TABLE `oc_megamenu_row` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

