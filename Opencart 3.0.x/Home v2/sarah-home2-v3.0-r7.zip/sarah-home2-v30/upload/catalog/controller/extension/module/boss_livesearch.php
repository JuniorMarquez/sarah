<?php

class ControllerExtensionModuleBossLiveSearch extends Controller {
	public function index() {
		$this->load->model('setting/setting');
		$module_info = $this->model_setting_setting->getSetting('module_boss_livesearch');

		if ($module_info) {
			$data['price'] = (isset($module_info['module_boss_livesearch_price'])) ? (int)$module_info['module_boss_livesearch_price'] : 0;
			$data['image'] = (isset($module_info['module_boss_livesearch_image'])) ? (int)$module_info['module_boss_livesearch_image'] : 0;
			$data['limit'] = (isset($module_info['module_boss_livesearch_limit'])) ? (int)$module_info['module_boss_livesearch_limit'] : 5;

			return $this->load->view('extension/module/boss_livesearch', $data);
		}
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('catalog/product');
			$this->load->model('tool/image');

			$width  = $this->config->get('module_boss_livesearch_width');
			$height = $this->config->get('module_boss_livesearch_height');

			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			if (isset($this->request->get['category_id'])) {
				$filter_category_id = $this->request->get['category_id'];
			} else {
				$filter_category_id = '';
			}

			if (isset($this->request->get['limit'])) {
				$limit = $this->request->get['limit'];
			} else {
				$limit = 5;
			}

			$filter_data = array(
				'filter_name'        => $filter_name,
				'filter_category_id' => $filter_category_id,
				'start'              => 0,
				'limit'              => $limit,
			);

			$results = $this->model_catalog_product->getProducts($filter_data);

			foreach ($results as $result) {
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $width, $height);
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $width, $height);
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				$json[] = array(
					'product_id' => $result['product_id'],
					'name'       => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'model'      => $result['model'],
					'image'      => $image,
					'price'      => $price,
					'href'       => $this->url->link('product/product', 'product_id=' . $result['product_id']),
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}