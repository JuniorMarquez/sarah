<?php
$_['button_read_more']			= 'Read more';