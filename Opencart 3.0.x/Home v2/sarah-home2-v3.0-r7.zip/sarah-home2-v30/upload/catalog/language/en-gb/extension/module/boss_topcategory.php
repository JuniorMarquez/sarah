<?php
// Heading
$_['heading_all']  = 'See the Collection';
$_['text_product'] = 'Products';
$_['button_shop']  = 'Shop Now';