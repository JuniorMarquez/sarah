<?php

// Text
$_['text_product_added']     = 'Product Added';
$_['text_customer_bought']   = 'Customers also bought';
$_['text_tax']               = 'Ex Tax:';
$_['text_item']              = 'items';


// Button
$_['button_close'] 		 = 'Close';