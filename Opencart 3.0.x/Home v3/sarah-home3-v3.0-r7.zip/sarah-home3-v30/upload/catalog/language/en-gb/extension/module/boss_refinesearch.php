<?php
// Heading
$_['heading_title'] = 'Boss Refine Search';