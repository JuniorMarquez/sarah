<?php
// Heading
$_['heading_title'] = 'Boss - Top Category';

// Text
$_['text_module']            = 'Modules';
$_['text_success']           = 'Success: You have modified module Boss - Top Category!';
$_['text_choose_categories'] = 'Choose categories';
$_['text_static']            = 'Static';
$_['text_slide']             = 'Slide';
$_['text_masonry']           = 'Masonry';
$_['text_red']               = 'Red';
$_['text_orange']            = 'Orange';
$_['text_yellow']            = 'Yellow';
$_['text_green']             = 'Green';
$_['text_blue']              = 'Blue';
$_['text_teal']              = 'Teal';
$_['text_purple']            = 'Purple';
$_['text_black']             = 'Black';
$_['text_first']             = 'First';
$_['text_last']              = 'Last';

// Entry
$_['entry_name']         = 'Module Name';
$_['entry_limit']        = 'Limit';
$_['entry_image_width']  = 'Image Width';
$_['entry_image_height'] = 'Image Height';
$_['entry_status']       = 'Status';
$_['entry_title']        = 'Title';
$_['entry_column']       = 'Column';
$_['entry_num_row']      = 'Num row';
$_['entry_per_row']      = 'Per row';
$_['entry_style']        = 'Style';
$_['entry_skin']         = 'Skin';

//button
$_['button_add_module'] = 'Add module';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify module Boss - Top Category!';
$_['error_limit']        = 'Limit required!';
$_['error_name']         = 'Module Name must be between 3 and 64 characters!';
$_['error_category']     = 'Category required!';
$_['error_num_row']      = 'Num row required!';
$_['error_per_row']      = 'Per row required!';
$_['error_image_width']  = 'Image Width required!';
$_['error_image_height'] = 'Image Height required!';