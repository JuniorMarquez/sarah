<?php

class ControllerExtensionModuleBossProductTab extends Controller {
	public function index($setting) {
		static $module = 0;

		if (empty($setting['tab'])) {
			return NULL;
		}

		if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_product_tab.css')) {
			$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/boss_product_tab.css');
		} else {
			$this->document->addStyle('catalog/view/theme/default/stylesheet/bossthemes/boss_product_tab.css');
		}

		$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/swiper.min.css');
		$this->document->addScript('catalog/view/javascript/jquery/swiper/js/swiper.jquery.min.js');

		if (file_exists('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css')) {
			$this->document->addStyle('catalog/view/theme/' . $this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '/stylesheet/bossthemes/swiper.css');
		} else {
			$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/opencart.css');
		}

		$language_id        = $this->config->get('config_language_id');
		$image_width        = (!empty($setting['image_width'])) ? (int)$setting['image_width'] : 450;
		$image_height       = (!empty($setting['image_height'])) ? (int)$setting['image_height'] : 450;
		$description_length = (!empty($setting['description_length'])) ? (int)$setting['description_length'] : 108;
		$limit              = (!empty($setting['limit'])) ? (int)$setting['limit'] : 8;
		$text_save_off      = $this->config->get('boss_phrase_text_save_off');

		$data['text_save_off']  = (isset($text_save_off[$language_id])) ? $text_save_off[$language_id] : '';
		$data['heading_title']  = (isset($setting['title'][$language_id])) ? html_entity_decode($setting['title'][$language_id]) : '';
		$data['description']    = (isset($setting['description'][$language_id])) ? html_entity_decode($setting['description'][$language_id]) : '';
		$data['custom']         = (isset($setting['custom'][$language_id])) ? html_entity_decode($setting['custom'][$language_id]) : '';
		$data['custom_status']  = (isset($setting['custom_status'])) ? (int)$setting['custom_status'] : 0;
		$data['column']         = (isset($setting['column'])) ? (int)$setting['column'] : 4;
		$data['num_row']        = (isset($setting['num_row'])) ? (int)$setting['num_row'] : 1;
		$data['per_row']        = (isset($setting['per_row'])) ? (int)$setting['per_row'] : 4;
		$data['pagination']     = (isset($setting['pagination'])) ? (int)$setting['pagination'] : 0;
		$data['navigation']     = (isset($setting['navigation'])) ? (int)$setting['navigation'] : 0;
		$data['nav_position']   = (isset($setting['nav_position'])) ? $setting['nav_position'] : 'nav-top';
		$data['nav_state']      = (isset($setting['nav_state'])) ? $setting['nav_state'] : '';
		$data['product_layout'] = (isset($setting['nav_position'])) ? $setting['product_layout'] : 'product-grid';
		$data['skin']           = (isset($setting['skin'])) ? $setting['skin'] : 'black';
		$data['sidebar']        = ($setting['style'] == 'sidebar') ? 1 : 0;
		$data['slidable']       = (isset($setting['slidable'])) ? (int)$setting['slidable'] : 0;

		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$data['tabs'] = array();

		foreach ($setting['tab'] as $tab) {
			$results = array();

			if ($tab['filter'] == "popular") {
				$results = $this->model_catalog_product->getPopularProducts($limit);
			} elseif ($tab['filter'] == "special") {
				$filter_vars = array(
					'sort'  => 'p.date_added',
					'order' => 'DESC',
					'start' => 0,
					'limit' => $limit,
				);

				$results = $this->model_catalog_product->getProductSpecials($filter_vars);
			} elseif ($tab['filter'] == "best_seller") {
				$results = $this->model_catalog_product->getBestSellerProducts($limit);
			} elseif ($tab['filter'] == "latest") {
				$results = $this->model_catalog_product->getLatestProducts($limit);
			} elseif ($tab['filter'] == "rating") {
				$filter_vars = array(
					'sort'  => 'p.date_added',
					'order' => 'DESC',
					'start' => 0,
					'limit' => $limit,
				);

				$results = $this->model_catalog_product->getProducts($filter_vars);
			} elseif ($tab['filter'] == "category") {
				$filter_vars = array(
					'filter_category_id' => $tab['filter_type_category'],
					'sort'               => 'p.date_added',
					'order'              => 'DESC',
					'start'              => 0,
					'limit'              => $limit,
				);

				$results = $this->model_catalog_product->getProducts($filter_vars);
			} elseif ($tab['filter'] == "featured") {
				if (isset($tab['product_featured']) && is_array($tab['product_featured'])) {
					foreach ($tab['product_featured'] as $product_id) {
						$product_info = $this->model_catalog_product->getProduct($product_id);

						if ($product_info) {
							$results[$product_id] = $product_info;
						}
					}
				}
			}

			$products = array();

			foreach ($results as $result) {
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $image_width, $image_height);
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $image_width, $image_height);
				}

				$images = array();

				$product_images = $this->model_catalog_product->getProductImages($result['product_id']);

				foreach ($product_images as $product_image) {
					$images[] = $this->model_tool_image->resize($product_image['image'], $image_width, $image_height);
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = (int)$result['rating'];
				} else {
					$rating = false;
				}

				$products[] = array(
					'product_id'  => $result['product_id'],
					'thumb'       => $image,
					'images'      => $images,
					'name'        => $result['name'],
					'description' => ((int)$description_length) ? utf8_substr(trim(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8'))), 0, (int)$description_length) . '..' : '',
					'price'       => $price,
					'special'     => $special,
					'saving'      => sprintf($data['text_save_off'], ($result['price'] == 0) ? 100 : round((($result['price'] - $result['special']) / $result['price']) * 100, 0)),
					'tax'         => $tax,
					'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
					'rating'      => $rating,
					'href'        => $this->url->link('product/product', 'product_id=' . $result['product_id']),
				);
			}

			$data['tabs'][] = array(
				'name'     => (isset($tab['name'][$language_id])) ? $tab['name'][$language_id] : '',
				'products' => $products,
			);
		}

		$data['module'] = $module++;

		return $this->load->view('extension/module/boss_product_tab', $data);
	}

	public function getProduct() {
		$json = array();

		if (!empty($this->request->post['product_id'])) {
			if (isset($this->request->post['img_width'])) {
				$img_width = (int)$this->request->post['img_width'];
			} else {
				$img_width = (int)$this->config->get($this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '_image_product_width');
			}

			if (isset($this->request->post['img_height'])) {
				$img_height = (int)$this->request->post['img_height'];
			} else {
				$img_height = (int)$this->config->get($this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '_image_product_height');
			}

			if (isset($this->request->post['add_img_width'])) {
				$add_img_width = (int)$this->request->post['add_img_width'];
			} else {
				$add_img_width = (int)$this->config->get($this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '_image_additional_width');
			}

			if (isset($this->request->post['add_img_height'])) {
				$add_img_height = (int)$this->request->post['add_img_height'];
			} else {
				$add_img_height = (int)$this->config->get($this->config->get('theme_' . $this->config->get('config_theme') . '_directory') . '_image_additional_height');
			}

		} else {
			$json = array(
				'result' => 'error',
			);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}