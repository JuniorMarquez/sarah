<?php
$_['text_main']        = 'MAIN NAVIGATION';
$_['text_manager']     = 'General';
$_['text_header']      = 'Header';
$_['text_footer']      = 'Footer';
$_['text_society']     = 'Society';
$_['text_payment']     = 'Payment';
$_['text_widget']      = 'Widgets';
$_['text_font_color']  = 'Font & Color';
$_['text_custom']      = 'Custom';
$_['text_phrase']      = 'Phrase';
$_['text_sample_data'] = 'Sample Data';
$_['text_xml']         = 'XML OCMod';
$_['text_module']      = 'MODULE';